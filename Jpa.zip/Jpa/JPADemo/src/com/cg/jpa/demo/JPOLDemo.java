package com.cg.jpa.demo;

import java.util.List;

import javax.persistence.Query;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.cg.jpa.entity.Account;

public class JPOLDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=emf.createEntityManager();
		/*
		// Inserting records into account_info
		Account ac1=new Account();
		ac1.setAccHolderName("Nikhil");
		ac1.setBalance(45000);
		ac1.setMobileNo("919204320324");
		Account ac2=new Account();
		ac2.setAccHolderName("Ajay");
		ac2.setBalance(34000);
		ac2.setMobileNo("4320324");
		Account ac3=new Account();
		ac3.setAccHolderName("Vidya");
		ac3.setBalance(36000);
		ac3.setMobileNo("35320324");
		Account ac4=new Account();
		ac4.setAccHolderName("Nikhil");
		ac4.setBalance(40000);
		ac4.setMobileNo("94320324");
		em.getTransaction().begin();
		em.persist(ac1);
		em.persist(ac2);
		em.persist(ac3);
		em.persist(ac4);
		em.getTransaction().commit();
		System.out.println("Accounts added");
		*/
		/*
		// Printing all the account details
		String qry1="select acc from Account acc";
		Query query=em.createQuery(qry1);
		List<Account> acclist=query.getResultList();
		for(Account ac:acclist)
		{
			
			System.out.println(ac.getAccountNo()+" "+ac.getAccHolderName()+" "+ac.getMobileNo()+" "+ac.getBalance());
		}
		
		// retrieving balance using condition
		String qry="select acc.balance from Account acc where acc.balance>36000" ;
		TypedQuery<Double> tq=em.createQuery(qry,Double.class);
		List<Double> acclist1=tq.getResultList();
		System.out.println(acclist1);
		
		// Maximum balance
		String qry2="select max(acc.balance) from Account acc" ;
		TypedQuery<Double> tq1=em.createQuery(qry2,Double.class);
		double maxbal=tq1.getSingleResult();
		System.out.println("Maximum balance:"+maxbal);
		*/
		/*
		// updating balance =========> We have to do commit in sql first and then execute the query
				String qry4="update Account acc set acc.balance=acc.balance*1.1" ;
				em.getTransaction().begin();
				Query query1=em.createQuery(qry4);
				int rows=query1.executeUpdate();
				System.out.println(rows+"updated");
				em.getTransaction().commit();
		*/
		
		
		
		//Dynamic query
		//String qry5="select acc.accHolderName from Account acc where acc.balance between :b1 and :b2" ;
		TypedQuery<String> tq=em.createNamedQuery("getNames",String.class);
		tq.setParameter("b1", 100000.00);
		tq.setParameter("b2", 200000.00);
		List<String> namelist=tq.getResultList();
		for(String s:namelist)
		{
			System.out.println(s);
		}
		
		

	}

}
