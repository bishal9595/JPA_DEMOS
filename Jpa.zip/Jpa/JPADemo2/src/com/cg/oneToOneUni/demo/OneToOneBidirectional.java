package com.cg.oneToOneUni.demo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class OneToOneBidirectional {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=emf.createEntityManager();
		Student s1=new Student();
		Address a1=new Address();
		a1.setCity("Pune");
		a1.setCountry("india");
		s1.setName("Abc");
		s1.setAddress(a1);
		
		Student s2=new Student();
		Address a2=new Address();
		a2.setCity("Mumbai");
		a2.setCountry("India");
		s2.setName("Abc1");
		s2.setAddress(a2);
		
		em.getTransaction().begin();
		em.persist(a1);
		em.persist(s1);
		em.getTransaction().commit();

	}

}
